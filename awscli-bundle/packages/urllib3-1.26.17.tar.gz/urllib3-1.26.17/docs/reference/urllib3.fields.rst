Fields and Multipart Forms
==========================

Fields
------

.. automodule:: urllib3.fields
    :members:
    :undoc-members:
    :show-inheritance:


Multipart Forms
---------------

.. autofunction:: urllib3.encode_multipart_formdata
.. autofunction:: urllib3.filepost.choose_boundary
.. autofunction:: urllib3.filepost.iter_field_objects
